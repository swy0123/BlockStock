INSERT INTO board.free_post (created_at, hit, id, member_id, updated_at, content, title) VALUES ('2023-10-05 21:59:21.239106', 15, 106, 50, '2023-10-05 21:59:21.239106', '안녕하세요 삼전 매수했습니다.

언제 매도할까요???', '언제 매도할까요? (삼성전자)');
INSERT INTO board.free_post (created_at, hit, id, member_id, updated_at, content, title) VALUES ('2023-10-05 21:59:51.904201', 21, 107, 10, '2023-10-05 21:59:51.904201', '뭐가 맞는거 같아요?', '장기 투자 vs 단타');
INSERT INTO board.free_post (created_at, hit, id, member_id, updated_at, content, title) VALUES ('2023-10-05 22:04:21.522472', 11, 108, 13, '2023-10-05 22:04:21.522472', '잘부탁드려용 ~', '새로 가입한 주린이입니다!');
INSERT INTO board.free_post (created_at, hit, id, member_id, updated_at, content, title) VALUES ('2023-10-05 22:06:32.265114', 11, 109, 13, '2023-10-05 22:06:32.265114', '뭐살까요 ?', '종목 추천 해주세요 !!');
INSERT INTO board.free_post (created_at, hit, id, member_id, updated_at, content, title) VALUES ('2023-10-05 22:22:20.920006', 30, 117, 39, '2023-10-05 22:22:20.920006', '궁금하신가요? 쪽지 ㄱㄱ', '삼성화재 120수익 얻은 썰');
INSERT INTO board.free_post (created_at, hit, id, member_id, updated_at, content, title) VALUES ('2023-10-05 22:25:46.983000', 9, 118, 2, '2023-10-05 22:32:46.983132', '쉽게가는 전략입니다 ~', '제 전략 어때요?');
INSERT INTO board.free_post (created_at, hit, id, member_id, updated_at, content, title) VALUES ('2023-10-05 22:50:03.627255', 14, 119, 50, '2023-10-05 22:50:03.627255', '비법좀', '아 주식고수 되고싶다 ,,');
INSERT INTO board.free_post (created_at, hit, id, member_id, updated_at, content, title) VALUES ('2023-10-05 22:56:57.787005', 24, 120, 51, '2023-10-05 22:56:57.787005', '확인하세요 ~!', '10.05 시장 후 주요뉴스입니다.');
INSERT INTO board.free_post (created_at, hit, id, member_id, updated_at, content, title) VALUES ('2023-10-06 03:41:59.025019', 1, 121, 13, '2023-10-06 03:41:59.025019', '하이테이블에서 양 발 뻗고 의자에 앉아서 RSI 전략 짰다

근데 그거 알아? 그 옆에 있는 여자 분도 있는데, 그 분도 알고리즘 진짜 잘 짜셔


그리고 둘이 이 서비스 전략 테스트 서비스 만들엇대

대박이지 짱인거같아 멋있다 멋있어


나도 열심히 해서 두 사람처럼 멋있는 사람 돼야지', '[속보] 투자의 신 정체');
INSERT INTO board.free_post (created_at, hit, id, member_id, updated_at, content, title) VALUES ('2023-10-06 04:08:12.001576', 1, 122, 39, '2023-10-06 04:08:12.001576', '무슨 주식 사지', '로또말고 주식 부자 되고 싶어요..');
