INSERT INTO board.free_post_comment (created_at, free_post_id, id, member_id, updated_at, content) VALUES ('2023-10-05 23:55:27.512826', 120, 47, 39, '2023-10-05 23:55:27.512826', '감사합니다 :)');
INSERT INTO board.free_post_comment (created_at, free_post_id, id, member_id, updated_at, content) VALUES ('2023-10-05 23:56:23.123064', 109, 48, 39, '2023-10-05 23:56:23.123064', '삼성화재가 상승주 각입니다');
INSERT INTO board.free_post_comment (created_at, free_post_id, id, member_id, updated_at, content) VALUES ('2023-10-06 00:42:54.874173', 120, 49, 10, '2023-10-06 00:42:54.874173', '항상 감사합니다 ~');
INSERT INTO board.free_post_comment (created_at, free_post_id, id, member_id, updated_at, content) VALUES ('2023-10-06 03:14:18.952221', 107, 51, 51, '2023-10-06 03:14:18.952221', '우수합니다');
INSERT INTO board.free_post_comment (created_at, free_post_id, id, member_id, updated_at, content) VALUES ('2023-10-06 03:28:56.298261', 109, 53, 13, '2023-10-06 03:28:56.298261', '삼성화재 가겠습니다.');
INSERT INTO board.free_post_comment (created_at, free_post_id, id, member_id, updated_at, content) VALUES ('2023-10-06 03:44:28.125027', 107, 54, 13, '2023-10-06 03:44:28.125027', '투자의 신은 어떻게 생각하시나요? 전문자의 의견이 궁금해요');
INSERT INTO board.free_post_comment (created_at, free_post_id, id, member_id, updated_at, content) VALUES ('2023-10-06 03:45:00.339015', 117, 57, 13, '2023-10-06 03:45:00.339015', '허걱 저 궁금해요 알려줘요');
INSERT INTO board.free_post_comment (created_at, free_post_id, id, member_id, updated_at, content) VALUES ('2023-10-06 03:47:35.971879', 120, 60, 51, '2023-10-06 03:47:35.971879', '');
