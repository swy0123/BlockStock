INSERT INTO board.tactic_post_comment (created_at, id, member_id, tactic_post_id, updated_at, content) VALUES ('2023-10-05 21:22:00.708750', 114, 51, 65, '2023-10-05 21:22:00.708750', '좋아요');
INSERT INTO board.tactic_post_comment (created_at, id, member_id, tactic_post_id, updated_at, content) VALUES ('2023-10-05 21:35:31.989891', 115, 51, 65, '2023-10-05 21:35:31.989891', '좋아요 된다');
INSERT INTO board.tactic_post_comment (created_at, id, member_id, tactic_post_id, updated_at, content) VALUES ('2023-10-05 21:58:34.963745', 116, 51, 66, '2023-10-05 21:58:34.963745', '손해이군요...');
INSERT INTO board.tactic_post_comment (created_at, id, member_id, tactic_post_id, updated_at, content) VALUES ('2023-10-06 00:40:53.878752', 119, 13, 68, '2023-10-06 00:40:53.878752', '와 배우고싶다 !!!');
INSERT INTO board.tactic_post_comment (created_at, id, member_id, tactic_post_id, updated_at, content) VALUES ('2023-10-06 00:42:25.507531', 121, 10, 68, '2023-10-06 00:42:25.507531', '주식의 신이 인정합니다.');
INSERT INTO board.tactic_post_comment (created_at, id, member_id, tactic_post_id, updated_at, content) VALUES ('2023-10-06 01:18:23.302958', 122, 13, 69, '2023-10-06 01:18:23.302958', '와 멋져요 !!! 배워갑니다');
INSERT INTO board.tactic_post_comment (created_at, id, member_id, tactic_post_id, updated_at, content) VALUES ('2023-10-06 01:18:52.563641', 123, 50, 69, '2023-10-06 01:18:52.563641', '친하게 지내요');
INSERT INTO board.tactic_post_comment (created_at, id, member_id, tactic_post_id, updated_at, content) VALUES ('2023-10-06 03:05:17.626733', 124, 51, 67, '2023-10-06 03:05:17.626733', 'df
dsfgdf
dfg');
INSERT INTO board.tactic_post_comment (created_at, id, member_id, tactic_post_id, updated_at, content) VALUES ('2023-10-06 03:36:02.631677', 125, 13, 71, '2023-10-06 03:36:02.631677', '투자의 신님 대박이세요
어디서 본거 같은데,,,, 어디더라,,,, 볼록 팀 UCC?,,,,');
INSERT INTO board.tactic_post_comment (created_at, id, member_id, tactic_post_id, updated_at, content) VALUES ('2023-10-06 03:37:15.602301', 126, 50, 71, '2023-10-06 03:37:15.602301', '와 멋져요 !! 배워갑니다');
INSERT INTO board.tactic_post_comment (created_at, id, member_id, tactic_post_id, updated_at, content) VALUES ('2023-10-06 03:47:47.941552', 127, 51, 70, '2023-10-06 03:47:47.941552', '');
